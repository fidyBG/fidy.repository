# -*- coding: utf-8 -*-
import os
import time
import xbmc
import xbmcaddon
import xbmcvfs

KEEPALIVE_SECS = 5 * 60   # Bulsat's own player asks "what's on now" every 5 min

__profile__ = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
SESSION_FILE = os.path.join(xbmcvfs.translatePath(os.path.join(__profile__, 'dat')), 'session.json')


def keepalive_on():
  return xbmcaddon.Addon().getSetting('keepalive') == 'true'


def send_keepalive(gone=None):
  # One small request with our own session. It never signs in, so it cannot
  # end the session of another device on the same account.
  # True = alive, False = Bulsat ended the session, None = no answer / nothing to do
  import requests
  import simplejson as json
  try:
    with open(SESSION_FILE, 'r') as f:
      data = json.load(f)
  except Exception:
    return None, None
  session = data.get('session', '')
  if not session or session == gone:
    return None, None   # nothing to keep alive (yet / any more)

  channel = data.get('channel', '')
  title = xbmc.getInfoLabel('VideoPlayer.ChannelName')
  if title:   # the channel being watched, if it is one of ours
    cmap = data.get('channel_map', {})
    channel = cmap.get(title) or next((v for k, v in cmap.items() if k.lower() == title.lower()), channel)

  hdrs = {'SSBULSATAPI': session,
          'User-Agent': data.get('ua') or 'okhttp/3.12.12',
          'Accept-Language': 'bg-BG,en-US;q=0.9'}
  try:
    r = requests.post(data.get('base', 'https://api.iptv.bulsat.com') + '/epg/short',
                      data={'epg': 'nownext', 'channel': channel or 'bnt1_hd'},
                      headers=hdrs, timeout=10)
  except Exception as e:
    xbmc.log('bscfusion service: keepalive no answer - %s' % e, xbmc.LOGWARNING)
    return session, None

  logged = ''
  try:
    d = r.json()
    if isinstance(d, dict):
      logged = str(d.get('Logged', d.get('logged', ''))).lower()
  except ValueError:
    pass
  if r.status_code in (401, 403) or logged == 'false':
    return session, False
  if r.status_code != 200:
    return session, None

  # remember when the session was last seen alive - exec.py trusts the cached
  # links only while this is fresh; never overwrite a newer login
  try:
    with open(SESSION_FILE, 'r') as f:
      cur = json.load(f)
    if cur.get('session') == session:
      cur['alive'] = time.time()
      with open(SESSION_FILE + '.tmp', 'w') as f:
        json.dump(cur, f)
      os.replace(SESSION_FILE + '.tmp', SESSION_FILE)
  except Exception:
    pass
  return session, True


xbmc.log('bscfusion service: started', xbmc.LOGINFO)
xbmc.executebuiltin('RunScript(plugin.program.bscfusion, False)')

monitor = xbmc.Monitor()
last = time.time()
gone = None        # a session Bulsat already ended - no point asking again
state = None

while not monitor.waitForAbort(60):
  if not keepalive_on() or time.time() - last < KEEPALIVE_SECS:
    continue
  last = time.time()
  try:
    session, r = send_keepalive(gone)
  except Exception as e:
    xbmc.log('bscfusion service: keepalive error - %s' % e, xbmc.LOGERROR)
    continue
  if session is None:
    continue
  if r is False:
    gone = session
    xbmc.log('bscfusion service: Bulsat ended the session - no new sign-in here, '
             'fresh links at the next refresh', xbmc.LOGWARNING)
  elif r and state is not True:
    xbmc.log('bscfusion service: keeping the session alive (every %d min)' % (KEEPALIVE_SECS // 60), xbmc.LOGINFO)
  state = r
