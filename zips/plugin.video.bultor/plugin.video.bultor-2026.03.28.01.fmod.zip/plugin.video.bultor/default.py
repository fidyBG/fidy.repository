# -*- coding: utf-8 -*-
import os
import re
import sys
import requests
import xbmc, xbmcplugin,xbmcgui,xbmcaddon
import urllib
import requests
import base64
import xbmcvfs
from datetime import datetime
from bs4 import BeautifulSoup
from urllib.parse import urlparse, parse_qs
import hashlib
import urllib.parse
import tempfile


__addon__ = xbmcaddon.Addon()
__icon__ = __addon__.getAddonInfo('icon')
__cwd__ = xbmcvfs.translatePath( __addon__.getAddonInfo('path') )
__profile__ = xbmcvfs.translatePath( __addon__.getAddonInfo('profile') )
__icon_search__ = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources', 'search.png' ) )
__icon_clear__ = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources', 'clear.png' ) )
__icon_folders__ = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources', 'movies.png' ) )
__icon_sresult__ = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources', 'search-result.png' ) )
__icon_emptyfolder__ = xbmcvfs.translatePath( os.path.join( __cwd__, 'resources', 'empty.png' ) )

searchlist = __addon__.getSetting('searchlist')

def Notify (msg1, msg2):
      xbmc.executebuiltin((u'Notification(%s,%s,%s,%s)' % (msg1, msg2, '5000', __icon_folders__)))

if __addon__.getSetting('firstrun') == 'true':
  Notify('Грешка!', 'Проверете настройките.')
  __addon__.openSettings()
  __addon__.setSetting('firstrun', 'false')


if __addon__.getSetting('xxx') == 'true':
    xxx = True
else:
    xxx = False

if not __addon__.getSetting('username'):
    Notify('Потребител', 'празно')
if not __addon__.getSetting('password'):
    Notify('Парола', 'празно')

usr = __addon__.getSetting('username'),
passwd = __addon__.getSetting('password')


__categories__ = [
                    {'cat_ids':'13','cat_name':u'Филми - 4K'},
                    {'cat_ids':'11','cat_name':u'Филми - HD'},
                    {'cat_ids':'12','cat_name':u'Филми - SD'},
                    {'cat_ids':'16','cat_name':u'Филми - 4K Boxset'},
                    {'cat_ids':'14','cat_name':u'Филми - HD Boxset'},
                    {'cat_ids':'15','cat_name':u'Филми - SD Boxset'},
                    {'cat_ids':'18','cat_name':u'Филми - DVD'},
                    {'cat_ids':'21','cat_name':u'Сериали - 4K'},
                    {'cat_ids':'20','cat_name':u'Сериали - HD'},
                    {'cat_ids':'22','cat_name':u'Сериали - SD'},
                    {'cat_ids':'24','cat_name':u'Сериали - 4K Boxset'},
                    {'cat_ids':'23','cat_name':u'Сериали - HD Boxset'},
                    {'cat_ids':'25','cat_name':u'Сериали - SD Boxset'},
                    {'cat_ids':'8','cat_name':u'Аниме'},
                    {'cat_ids':'9','cat_name':u'Документални'},
                    {'cat_ids':'10','cat_name':u'Други'}
                  ]

if xxx == True:
      __categories__ += [
                          {'cat_ids':'7','cat_name':u'XXX'}
                        ]


UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'
headers_new = {'user-agent': UA}

s = requests.Session()

baseurl = 'https://bultor.net'
loginurl = '/en/account/login.php'
searchurl = baseurl + '/search/?cat=&q='

values = {'username': usr,
          'password': passwd}

r = s.post(baseurl+loginurl, data=values, headers=headers_new)

def CATEGORIES():
    FilmiYear = int(datetime.now().date().strftime("%Y"))

    addDir(u'Търсене', searchurl, 4, '', __icon_search__)
    addDir(u'Последно добавени', baseurl, 1, '', __icon_folders__)
    addDir(u'Филми от ' + str(FilmiYear) + u' година', searchurl + str(FilmiYear), 1, '', __icon_folders__)
    addDir(u'Филми от ' + str(FilmiYear - 1) + u' година', searchurl + str(FilmiYear - 1), 1,'', __icon_folders__)
    addDir(u'Филми от ' + str(FilmiYear - 2) + u' година', searchurl + str(FilmiYear - 2), 1,'', __icon_folders__)

    for cat in __categories__:
        addDir(cat['cat_name'], baseurl + '/cat/' + cat['cat_ids'], 1, '', __icon_folders__)



def INDEXPAGES(name,url):
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')

    r = s.post(url, headers=headers_new)

    data = r.text

    soup = BeautifulSoup(data, 'html.parser')
    tables = soup.find_all("table", class_="table table-hover d-block")

    link_check = ''

    if tables:
        target_table = tables[0]

        rows = target_table.find_all('tr')

        category_ids = {'movie','tv','anime','sd-fill','documentary','porn'}

        for row in rows:
            # проверяваме категориите, дали са за филми/сериали
            th = row.find("th")
            if not th:
                continue

            data_th = str(th)
            if any(word in data_th.lower() for word in category_ids):
                desk = ''
                imdb_id = ''

                col = row.find("td")
                if not col:
                    continue

                # линк към страницата
                link_tag = col.find("a", href=True)
                if not link_tag:
                    continue

                link = link_tag["href"] if link_tag else None

                if link_check == link:
                    continue

                link_check = link

                r_page = s.post(link, headers=headers_new)

                data_page = r_page.text

                match_imdb_id = re.search('imdb.+?(tt\d+)', data_page)
                if match_imdb_id:
                    imdb_id = match_imdb_id.group(1)

                match_seeds = re.search('Seeders.+?(\d+)', data_page)

                if match_seeds and match_seeds.group(1) != '0':
                    seeders = match_seeds.group(1)
                else:
                    seeders = '1'

                match_leech = re.search('Leechers.+?(\d+)', data_page)

                if match_leech and match_leech.group(1) != '0':
                    leechers = match_leech.group(1)
                else:
                    leechers = '1'

                match_year = re.search('Година.+?(\d+)', data_page)

                if match_year:
                    year = match_year.group(1)
                else:
                    year = ''

                match_resume = re.search('Резюме.+?<h5>(.+?)</h5>', data_page)

                if match_resume:
                    resume = match_resume.group(1)
                else:
                    resume = ''

                match_torrent = re.search('(magnet:.+?)">', data_page)

                if not match_torrent:
                    continue

                torrent_url = match_torrent.group(1)

                # релийз
                release = link_tag.get_text(strip=True) if link_tag else None

                # заглавие
                name_tag = col.find("b")
                title = name_tag.get_text(strip=True) if name_tag else None

                if not title:
                    title = release

                # постер
                img = col.find("img")
                poster = img["src"] if img else None

                if not poster:
                    img = re.search("img src='(.+?)'", str(col))
                    if img:
                        poster = img.group(1)

                # размер
                size_tag = col.select_one(".float-end")
                size = size_tag.get_text(strip=True) if size_tag else None

                # жанрове
                genres = [g.get_text(strip=True) for g in col.select('a[href*="/genre/"]')]

                # --- BG Subs ---
                subs_img = re.search(u'(български субтитри)', str(col))
                if subs_img:
                    bg_subs = 'Да'
                else:
                    bg_subs = 'Не'

                # --- BG Audio ---
                audio_img = re.search(u'(Българско озвучение)', str(col))
                if audio_img:
                    bg_audio = 'Да'
                else:
                    bg_audio = 'Не'

                #desk = desk + str(release) + '\n'
                desk = desk + '[COLOR CC00FF00]Сийдъри: [/COLOR]' + str(seeders) + ' [COLOR CC00FF00]Лийчъри: [/COLOR]' + str(leechers) + '\n'
                desk = desk + '[COLOR CC00FF00]Размер: [/COLOR]' + str(size)

                if year != '':
                    desk = desk + '\n[COLOR CC00FF00]Година: [/COLOR]' + str(year)

                if genres:
                    desk = desk + '\n[COLOR CC00FF00]Жанр: [/COLOR]' + str(genres).replace('[','').replace(']','').replace("'","")

                # --- Качество ---
                match_quality = re.search('(\d+p)', release.replace('%20', '_'))

                if match_quality:
                    quality = match_quality.group(1)
                    desk = desk + '\n[COLOR CC00FF00]Качество: [/COLOR]' + str(quality)

                desk = desk + '\n\n[COLOR CC00FF00]Български субтитри: [/COLOR]' + str(bg_subs) + '\n'
                desk = desk + '[COLOR CC00FF00]Българско аудио: [/COLOR]' + str(bg_audio)

                if resume != '':
                    desk = desk + '\n\n' + str(resume)

                addLink(release, torrent_url, 2, desk, poster, imdb_id)

        # Следваща страница
        matchp = re.compile('page-link(.+?)<').findall(str(data))

        for pg in matchp:
            macth_next = re.search('(/page/\d+).+?Следваща', str(pg))
            if macth_next:
                newurl = re.sub(r'/page/\d+', '', url)
                addDir('[COLOR CC00FF00][B]Следваща страница >>>[/B][/COLOR]', newurl + macth_next.group(1), 1, '', '')
    else:
        pass

#Търсачка
def SEARCH(url):
    keyb = xbmc.Keyboard('', 'Търсене по заглавие')
    keyb.doModal()
    searchText = ''
    if (keyb.isConfirmed()):
        searchText = urllib.parse.quote_plus(keyb.getText())
        searchText=searchText

        searchText=searchText.replace('+',' ')
        INDEXPAGES('Търсене',url + searchText)
    else:
        CATEGORIES()


def PLAY(torrent_url):
    use_torrserve = __addon__.getSetting('player') == '1'

    if use_torrserve:
        p = 'plugin://plugin.video.torrserve/?action=gotInfo&magnet={}'.format(
            urllib.parse.quote_plus(torrent_url)
        )
        xbmc.executebuiltin('Container.Update({})'.format(p))
    else:
        uri = torrent_url
        elementum_url = f'plugin://plugin.video.elementum/play?uri={uri}'

        li = xbmcgui.ListItem(path=elementum_url)
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': name})
        try:
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
        except:
            xbmc.executebuiltin("Notification('Грешка','Видеото липсва на сървъра!')")
		
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


def addDir(name,url,mode,plot,iconimage):
        u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)+"&iconimage="+urllib.parse.quote_plus(iconimage)
        liz=xbmcgui.ListItem(name)

        ok=True
        liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage })
        liz.setInfo( type="Video", infoLabels={ "Title": name, "plot": plot } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addLink(name,url,mode,plot,iconimage,imdb_id):
        u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
        liz=xbmcgui.ListItem(name)

        ok=True
        liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage })
        liz.setInfo(type="Video", infoLabels={ "Title": name, "plot": plot, 'IMDBNumber': imdb_id } )
        liz.setProperty('fanart_image', iconimage)
        liz.setProperty("IsPlayable" , "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok


params=get_params()
url=None
name=None
iconimage=None
mode=None
count=None
groupID=None
ytpass=None


try:
        url=urllib.parse.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.parse.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.parse.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        count=int(params["count"])
except:
        pass
try:
        groupID=int(params["groupID"])
except:
        pass
try:
        ytpass=urllib.parse.unquote_plus(params["ytpass"])
except:
        pass

if mode==None or url==None or len(url)<1:
    print ("")
    CATEGORIES()

elif mode==4:
    print (""+url)
    SEARCH(url)

elif mode==1:
    print (""+url)
    INDEXPAGES(name,url)

elif mode==2:
        print (""+url)
        PLAY(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))