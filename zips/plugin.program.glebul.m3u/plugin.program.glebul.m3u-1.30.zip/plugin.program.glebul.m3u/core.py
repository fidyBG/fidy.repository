# -*- coding: utf-8 -*-
"""
Споделена логика - парсинг, генериране на M3U, refresh.
"""

import os
import re
from datetime import datetime, timedelta, timezone

import requests
import xbmc
import xbmcaddon
import xbmcvfs

ADDON      = xbmcaddon.Addon()
ADDON_DATA = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
BASE_URL   = 'https://glebul.com'
EPG_URL    = 'https://raw.githubusercontent.com/fidyBG/fidy.repository/main/bulsat.xml.gz'
UA         = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
              'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')

os.makedirs(ADDON_DATA, exist_ok=True)

_session = requests.Session()
_session.headers.update({'User-Agent': UA, 'Referer': f'{BASE_URL}/index.php'})


def setting_int(key, default):
    try:
        return int(ADDON.getSetting(key)) or default
    except Exception:
        return default


def output_dir():
    if ADDON.getSetting('custom_output_enabled') == 'true':
        path = ADDON.getSetting('custom_output_path').strip()
        if path:
            os.makedirs(path, exist_ok=True)
            return path
    return ADDON_DATA

EPG_MAP = {
    'BNT1':          'bnt1_hd',
    'BNT2':          'bnt2',
    'BNT3':          'bnt_hd',
    'BNT4':          'bntworld',
    'Nova':          'novatv',
    'bTV':           'btv',
    'bTVAction':     'btv_action',
    'bTVCinema':     'btv_cinema',
    'bTVComedy':     'btv_comedy',
    'bTVStory':      'bTVStory',
    'BulgariaOnAir': 'bulgaria_on_air',
    'CartoonNetwork':'cn',
    'DiemaFamily':   'diema_family',
    'Diema':         'diema',
    'Discovery':     'discovery',
    'Disney':        'disney_channel',
    'DSTV':          'dstv',
    'Ekids':         'ekids',
    'EpicDrama':     'epic_drama',
    'EuroNews':      'tvevropa',
    'Eurocom':       'evrokom',
    'FolklorTV':     'folklor_tv_hd',
    'FoodNetwork':   'food_network_hd',
    'STARCrime':     'fox_crime',
    'STARChannel':   'fox',
    'STARLife':      'fox_life',
    'ID':            'id_xtra',
    'KinoNova':      'kinonova',
    'NatGeo':        'nat_geo_hd',
    'NatGeoWild':    'nat_geo_wild',
    'NickJr':        'nick_jr',
    'Nickelodeon':   'nickelodeon',
    'Nicktoons':     'nicktoons',
    'NovaNews':      'nova_news',
    'PlanetaFolk':   'planeta_folk',
    'Planeta':       'planetahd',
    'Rodina':        'tv_rodina_hd',
    '78TV':          'sedemosm',
    'Skat':          'skat',
    'TheVoice':      'the_voice',
    'TiankovFolk':   'tiankov_folk_hd',
    'TLC':           'tlc',
    'TravelChannel': 'travel_channel',
    'Travel':        'travel_tv',
    'ViasatExplorer':'viasat_explorer',
    '24kitchen':     '24_kitchen',
    'AXN':           'AXN',
    'AXNBlack':      'AXNBlack',
    'AXNWhite':      'AXNWhite',
    'Bloomberg':     'bloomberg_tv',
    'City':          'city_tv',
    'VTK':           'vtk',
    'CodeFashion':   '359tv_hd',
}

def get_stream_url(channel):
    resp = _session.post(
        f'{BASE_URL}/flussonic.php',
        data={'channel': channel, 'utc_start': '0', 'duration_sec': '0'},
        timeout=15
    )
    raw = resp.json()
    m = re.search(r'media=(https?://.+)$', raw)
    return m.group(1) if m else raw

def parse_channels():
    html = _session.get(f'{BASE_URL}/index.php', timeout=15).text
    channels = []
    pattern = re.compile(
        r'src="(/images/tv-logo/([^"]+?)\.png)"\s[^>]*alt="([^"]+)"'
        r'[^>]*onclick="playVideo\(\'([^\']+)\',\'0\',\'0\',\s*\'1\'\)"'
    )
    seen = set()
    for logo_path, _logo_file, slug, ch_id in pattern.findall(html):
        if ch_id in seen:
            continue
        seen.add(ch_id)
        name = (slug.replace('hd-', '').replace('-hd', '')
                    .replace('-', ' ').title().strip())
        channels.append({
            'id':       ch_id,
            'name':     name,
            'slug':     slug,
            'logo_url': f'{BASE_URL}{logo_path}'
        })
    return channels

NAME_MAP = {
    '24 Kitchen':      '24 Kitchen HD',
    'Bnt 1':           'БНТ 1 HD',
    'Bnt 2':           'БНТ 2',
    'Bnt 3':           'БНТ 3 HD',
    'Bnt 4':           'БНТ 4',
    'Nova Tv':         'Nova HD',
    'Btv':             'bTV HD',
    'Btv Action':      'bTV Action HD',
    'Btv Cinema':      'bTV Cinema',
    'Btv Comedy':      'bTV Comedy HD',
    'Btv Story':       'bTV Story',
    'City Tv':         'CITY TV',
    'Code Fashion Tv': 'Code Fashion HD',
    'Dstv':            'DSTV',
    'Diema':           'Diema HD',
    'Diema Family':    'Diema Family HD',
    'E Kids':          'E-Kids',
    'Evrokom':         'Евроком',
    'Folklor Tv':      'Фолклор ТВ',
    'Id Xtra':         'Investigation HD',
    'Kino Nova':       'Kino Nova HD',
    'Nat Geo':         'Nat Geo HD',
    'Nat Geo Wild':    'Nat Geo Wild HD',
    'Planeta':         'Planeta HD',
    'Rodina Tv':       'Родина ТВ',
    '78 Tv':           '7/8 TV HD',
    'Skat':            'CKAT',
    'Star Channel':    'Star Channel HD',
    'Star Crime':      'Star Crime HD',
    'Star Life':       'Star Life HD',
    'Tiankov Tv':      'Tiankov Folk',
    'Tlc':             'TLC',
    'Travel Tv':       'Travel TV',
    'Vtk':             'Военен ТВ Канал',
    'Axn':             'AXN',
    'Axn Black':       'AXN Black',
    'Axn White':       'AXN White',
    'Bloomberg Tv':    'Bloomberg BG',
}


def generate_m3u(channels):
    lines = [f'#EXTM3U x-tvg-url="{EPG_URL}"']
    for ch in channels:
        cid = ch['id']
        try:
            stream_url = get_stream_url(cid)
        except Exception as exc:
            xbmc.log(f'[GleBul IPTV]: Пропуснат канал {cid}: {exc}', xbmc.LOGWARNING)
            continue
        epg_id = EPG_MAP.get(cid, cid)
        epg_id = EPG_MAP.get(cid, cid)
        display_name = NAME_MAP.get(ch['name'], ch['name'])
        logo = ch['logo_url']
        lines.append(
            f'#EXTINF:-1 tvg-id="{epg_id}" tvg-name="{display_name}" '
            f'tvg-logo="{logo}",{display_name}'
        )
        lines.append(stream_url)
    return '\n'.join(lines)

def refresh_files(on_progress=None):
    def _progress(pct, msg):
        xbmc.log(f'[GleBul IPTV] {msg}', xbmc.LOGINFO)
        if on_progress:
            on_progress(pct, msg)

    _progress(5, 'Изтегляне на списъка с канали...')
    channels = parse_channels()

    _progress(50, f'Генериране на m3u за {len(channels)} канала…')
    out = output_dir()
    with open(os.path.join(out, 'glebul.m3u'), 'w', encoding='utf-8') as f:
        f.write(generate_m3u(channels))

    _progress(100, f'Готово - {len(channels)} канала.')
