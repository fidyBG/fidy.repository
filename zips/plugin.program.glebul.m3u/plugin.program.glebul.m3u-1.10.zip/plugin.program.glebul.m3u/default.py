# -*- coding: utf-8 -*-
import os
import sys

import xbmc
xbmc.log('[GleBul IPTV] default.py стартира', xbmc.LOGINFO)

sys.path.insert(0, os.path.dirname(__file__))
import core

import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON  = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])


def manual_refresh():
    dialog = xbmcgui.DialogProgressBG()
    dialog.create('GleBul IPTV', 'Обновяване...')
    try:
        core.refresh_files(
            on_progress=lambda pct, msg: dialog.update(pct, 'GleBul IPTV', msg)
        )
        dialog.close()
        xbmcgui.Dialog().notification(
            'GleBul IPTV', 'm3u файла е готов!',
            xbmcgui.NOTIFICATION_INFO, 4000
        )
    except Exception as exc:
        dialog.close()
        xbmc.log(f'[GleBul IPTV]: Грешка при ръчно обновяване: {exc}', xbmc.LOGERROR)
        xbmcgui.Dialog().ok('[GleBul IPTV]: Грешка', str(exc))


manual_refresh()
xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
