# -*- coding: utf-8 -*-
"""
Споделена логика - парсинг, генериране на M3U, refresh.
"""

import os
import re
from datetime import datetime, timedelta, timezone

import requests
import xbmc
import xbmcaddon
import xbmcvfs

ADDON      = xbmcaddon.Addon()
ADDON_DATA = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
BASE_URL   = 'https://glebul.com'
EPG_URL    = 'https://www.open-epg.com/files/bulgaria2.xml.gz'
UA         = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
              'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')

os.makedirs(ADDON_DATA, exist_ok=True)

_session = requests.Session()
_session.headers.update({'User-Agent': UA, 'Referer': f'{BASE_URL}/index.php'})


def setting_int(key, default):
    try:
        return int(ADDON.getSetting(key)) or default
    except Exception:
        return default


def output_dir():
    if ADDON.getSetting('custom_output_enabled') == 'true':
        path = ADDON.getSetting('custom_output_path').strip()
        if path:
            os.makedirs(path, exist_ok=True)
            return path
    return ADDON_DATA


# ---------------------------------------------------------------------------
# EPG мапинг: glebul tvg-id -> open-epg channel id
# ---------------------------------------------------------------------------

EPG_MAP = {
    'BNT1':          'БНТ 1 HD.bg',
    'BNT2':          'БНТ 2 HD.bg',
    'BNT3':          'БНТ 3 HD.bg',
    'BNT4':          'БНТ 4 HD.bg',
    'Nova':          'Нова HD.bg',
    'bTV':           'bTV HD.bg',
    'bTVAction':     'bTV Action HD.bg',
    'bTVCinema':     'bTV Cinema HD.bg',
    'bTVComedy':     'bTV Comedy HD.bg',
    'bTVStory':      'bTV Story HD.bg',
    'BulgariaOnAir': 'BulgariaOnAir HD.bg',
    'CartoonNetwork':'Cartoon Network.bg',
    'DiemaFamily':   'Diema Family HD.bg',
    'Diema':         'Diema HD.bg',
    'Discovery':     'Discovery HD.bg',
    'Disney':        'Disney.bg',
    'DSTV':          'DSTV.bg',
    'Ekids':         'E-Kids.bg',
    'EpicDrama':     'Epic Drama HD.bg',
    'EuroNews':      'Euronews BG HD.bg',
    'Eurocom':       'Евроком HD.bg',
    'FolklorTV':     'Folklor.bg',
    'FoodNetwork':   'Food Network HD.bg',
    'STARCrime':     'STAR Crime HD.bg',
    'STARChannel':   'STAR Channel HD.bg',
    'STARLife':      'STAR Life HD.bg',
    'ID':            'ID Extra HD.bg',
    'KinoNova':      'Kino Nova HD.bg',
    'NatGeo':        'Nat Geo HD.bg',
    'NatGeoWild':    'NG Wild HD.bg',
    'NickJr':        'Nick Junior.bg',
    'Nickelodeon':   'Nickelodeon.bg',
    'Nicktoons':     'Nicktoons.bg',
    'NovaNews':      'Nova News HD.bg',
    'PlanetaFolk':   'Планета Фолк HD.bg',
    'Planeta':       'Планета HD.bg',
    'Rodina':        'Rodina TV.bg',
    '78TV':          '7/8 TV HD.bg',
    'Skat':          'СКАТ.bg',
    'TheVoice':      'The Voice HD.bg',
    'TiankovFolk':   'Тянков Фолк.bg',
    'TLC':           'TLC HD.bg',
    'TravelChannel': 'Travel Channel HD.bg',
    'Travel':        'Travel TV.bg',
    'ViasatExplorer':'ViasatExplore HD.bg',
    '24kitchen':     '24 Kitchen HD.bg',
    'AXN':           'AXN.bg',
    'AXNBlack':      'AXN Black.bg',
    'AXNWhite':      'AXN White.bg',
    'Bloomberg':     'Bloomberg BG.bg',
    'City':          'City TV HD.bg',
    'VTK':           'VTK.bg',
    'CodeFashion':   'Code Fashion TV.bg',
}


# ---------------------------------------------------------------------------
# Stream URL
# ---------------------------------------------------------------------------

def get_stream_url(channel):
    resp = _session.post(
        f'{BASE_URL}/flussonic.php',
        data={'channel': channel, 'utc_start': '0', 'duration_sec': '0'},
        timeout=15
    )
    raw = resp.json()
    m = re.search(r'media=(https?://.+)$', raw)
    return m.group(1) if m else raw


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------

def parse_channels():
    html = _session.get(f'{BASE_URL}/index.php', timeout=15).text
    channels = []
    pattern = re.compile(
        r'src="(/images/tv-logo/([^"]+?)\.png)"\s[^>]*alt="([^"]+)"'
        r'[^>]*onclick="playVideo\(\'([^\']+)\',\'0\',\'0\',\s*\'1\'\)"'
    )
    seen = set()
    for logo_path, _logo_file, slug, ch_id in pattern.findall(html):
        if ch_id in seen:
            continue
        seen.add(ch_id)
        name = (slug.replace('hd-', '').replace('-hd', '')
                    .replace('-', ' ').title().strip())
        channels.append({
            'id':       ch_id,
            'name':     name,
            'slug':     slug,
            'logo_url': f'{BASE_URL}{logo_path}'
        })
    return channels


# ---------------------------------------------------------------------------
# Мапинг на имена на канали
# ---------------------------------------------------------------------------

NAME_MAP = {
    'Bnt 1':         'БНТ 1 HD',
    'Bnt 2':         'БНТ 2',
    'Bnt 3':         'БНТ 3 HD',
    'Bnt 4':         'БНТ 4',
    'Nova Tv':       'Nova HD',
    'Btv':           'bTV HD',
    'Btv Action':    'bTV Action HD',
    'Btv Cinema':    'bTV Cinema',
    'Btv Comedy':    'bTV Comedy HD',
    'Btv Story':     'bTV Story',
    'City Tv':       'CITY TV',
    'Code Fashion Tv': 'Code Fashion HD',
    'Dstv':          'DSTV',
    'E Kids':        'E-Kids',
    'Folklor Tv':    'Фолклор ТВ',
    'Id Xtra':       'Investigation Discovery',
    'Rodina Tv':     'Родина ТВ',
    '78 Tv':         '7/8 TV HD',
    'Skat':          'CKAT',
    'Tiankov Tv':    'Tiankov Folk',
    'Tlc':           'TLC',
    'Travel Tv':     'Travel TV',
    'Vtk':           'Военен ТВ Канал',
    'Axn':           'AXN',
    'Axn Black':     'AXN Black',
    'Axn White':     'AXN White',
    'Bloomberg Tv':  'Bloomberg BG',
}


# ---------------------------------------------------------------------------
# M3U генератор
# ---------------------------------------------------------------------------

def generate_m3u(channels):
    lines = [f'#EXTM3U x-tvg-url="{EPG_URL}"']
    for ch in channels:
        cid = ch['id']
        try:
            stream_url = get_stream_url(cid)
        except Exception as exc:
            xbmc.log(f'[GleBul IPTV]: Пропуснат канал {cid}: {exc}', xbmc.LOGWARNING)
            continue
        epg_id = EPG_MAP.get(cid, cid)
        epg_id = EPG_MAP.get(cid, cid)
        display_name = NAME_MAP.get(ch['name'], ch['name'])
        logo = ch['logo_url']
        lines.append(
            f'#EXTINF:-1 tvg-id="{epg_id}" tvg-name="{display_name}" '
            f'tvg-logo="{logo}",{display_name}'
        )
        lines.append(stream_url)
    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# Refresh
# ---------------------------------------------------------------------------

def refresh_files(on_progress=None):
    def _progress(pct, msg):
        xbmc.log(f'[GleBul IPTV] {msg}', xbmc.LOGINFO)
        if on_progress:
            on_progress(pct, msg)

    _progress(5, 'Изтегляне на списъка с канали...')
    channels = parse_channels()

    _progress(50, f'Генериране на m3u за {len(channels)} канала…')
    out = output_dir()
    with open(os.path.join(out, 'glebul.m3u'), 'w', encoding='utf-8') as f:
        f.write(generate_m3u(channels))

    _progress(100, f'Готово - {len(channels)} канала.')
