# -*- coding: utf-8 -*-
import os
import sys
import time

import xbmc
import xbmcgui

sys.path.insert(0, os.path.dirname(__file__))
import core


class GlebulService(xbmc.Monitor):

    def _refresh_with_progress(self):
        dialog = xbmcgui.DialogProgressBG()
        dialog.create('GleBul IPTV', 'Обновяване...')
        try:
            core.refresh_files(
                on_progress=lambda pct, msg: dialog.update(pct, 'GleBul IPTV', msg)
            )
            dialog.close()
            xbmc.executebuiltin('Notification(GleBul IPTV, m3u файла е готов!)')
        except Exception as exc:
            dialog.close()
            xbmc.log(f'[GleBul IPTV]: Грешка при обновяване: {exc}', xbmc.LOGERROR)

    def run(self):
        refresh_hours = core.setting_int('refresh_hours', 3)

        if core.ADDON.getSetting('auto_refresh_on_start') == 'true':
            self._refresh_with_progress()

        last_refresh = time.time()
        while not self.waitForAbort(60):
            if time.time() - last_refresh >= refresh_hours * 3600:
                self._refresh_with_progress()
                last_refresh = time.time()

        xbmc.log('[GleBul IPTV]: Услугата спря!', xbmc.LOGINFO)


if __name__ == '__main__':
    GlebulService().run()
