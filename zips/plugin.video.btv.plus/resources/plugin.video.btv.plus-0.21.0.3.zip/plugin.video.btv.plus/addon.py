# -*- coding: utf-8 -*-
#Библиотеки, които използват python и Kodi в тази приставка
import re
import sys
import os
import urllib.request, urllib.error, urllib.parse
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import base64


#Място за дефиниране на константи, които ще се използват няколкократно из отделните модули
__addon_id__= 'plugin.video.btv.plus'
__Addon = xbmcaddon.Addon(__addon_id__)
__settings__ = xbmcaddon.Addon(id='plugin.video.btv.plus')


#Деклариране на константи
md = xbmcvfs.translatePath(__Addon.getAddonInfo('path') + "/resources/media/")

try:
    response = requests.get(base64.b64decode('aHR0cHM6Ly9hbmRyb21lZGEuZXUub3JnL2FkZG9ucy9nZXR1c2VyYWdlbnQucGhwP2FuPQ==').decode('utf-8')+__addon_id__, headers={'Accept': 'application/json', 'Accept-Charset': 'UTF-8', 'Accept-Language': 'bg,en-US;q=0.7,en;q=0.3', 'Accept-Encoding': 'identity'}, timeout=9)
    jsonrsp = response.json()
    UA = jsonrsp['hua']
except:
    UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:139.0) Gecko/20100101 Firefox/139.0' #За симулиране на заявка от компютърен браузър

bu = 'https://btvplus.bg'

#Хедъри за заявки услугата
bp_headers = {
	'User-Agent': UA,
	'authority': 'btvplus.bg',
	'accept': 'text/html, application/xhtml+xml, application/xml, application/json, text/plain, */*',
	'dnt': '1',
	'origin': bu,
	'Connection': 'keep-alive',
	'sec-fetch-site': 'cross-site',
	'sec-fetch-mode': 'cors',
	'sec-fetch-dest': 'empty',
	'referer': bu,
	'accept-language': 'bg-BG,bg;q=0.9,en;q=0.8',
	'Accept-Encoding': 'gzip'
					}


#Меню с директории в приставката
def CATEGORIES():
		#addDir('Search',bu+'/search/?q=','',5,md+'DefaultAddonsSearch.png') #Съдържанието е минимално и няма нужда от търсачка
		#addLink('btv на живо',bu+'/lbin/v3/btvplus/player_config.php?media_id=2110383625','','True','','','','',4,'http://logos.epg.cloudns.org/btv.png')
		addLink('btv на живо','google','','True','','','','',5,'http://logos.epg.cloudns.org/btv.png')
		addDir('Предавания',bu+'/predavaniya/','Предаванията на bTV',1,md+'DefaultFolder.png')
		addDir('Сериали',bu+'/seriali/','Сериалите, излъчвани по bTV',1,md+'DefaultFolder.png')
		addDir('Емисии',bu+'/novini/','Записи на емисии новини, спорт и прогноза за времето',1,md+'DefaultFolder.png') 
		
		

#Разлистване на всички заглавия в каталога
def LISTALL(url):
		#xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
		response = requests.get(url, headers=bp_headers)
		match = re.compile('<li class=\"swiper-slide\".{0,16}>\n	+<div class=\"image\">\n	+<a href=\"(.+?)\">\n	+<img src=\"(.+?)\" />\n	+<span class=\"title\">(.+?)</span>').findall(response.text)
		for link, cover, title in match:
			#title = link.rsplit('/', 1)[1].replace('-',' ').capitalize()
			if 'http' not in cover:
				cover = 'https:'+cover
			addDir(title,link,'',2,cover)
		if 'novini' in url:
			addDir('Новини','/search/?type=101','',2,md+'DefaultFolder.png')
			addDir('Спорт','/search/?type=102','',2,md+'DefaultFolder.png')
			addDir('Времето','/search/?type=103','',2,md+'DefaultFolder.png')


#Разлистване епизодите
def LISTEPISODES(url):
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
		response = requests.get(bu+url, headers=bp_headers)
		try:
			matchp = re.compile('<meta itemprop=\"description\" content=\"(.+?)\" />').findall(response.text.replace("\n", ""))
			for description in matchp:
				plot = description.replace('&quot;','"')
		except:
			plot = ''
		if ('type=' in url): #Емисии, заредени през търсачката
			match2 = re.compile(' <li class=\"search-item\">\n {10,30}<a href=\"(.+?)\">\n {20,30}<img src=\"(.+?)\">\n\n {20,30}<span class=\"shadow-cover\"></span>\n {20,30}<span class=\"title\">(.+?)</span>').findall(response.text)
			for link, cover, title in set(match2): #Премахни дубликатите
				#addLink(name,url,vd,hd,plot,author,rating,ar,mode,iconimage)
				addLink(title,link,'','True',plot,'','','',3,cover)
		else: #Обикновени предавания
			match1 = re.compile('<div class=\"episode\">\n	{5,10}<a href=\"(.+?)\">\n	{5,15}<img src=\"(.+?)\">\n	{0,30}\n	{0,15}<span class=\"shadow-cover\"></span>\n	{0,20}\n	{5,20}<div class=\"episode-info\">\n	{5,15}<span class=\"title\">(.+?)</span>\n\n	{10,30}<div class=\"video-length\">\n	{10,20}(\d{2}):(\d{2}):(\d{2})').findall(response.text)
			for link, cover, title, hours, minutes, seconds in set(match1): #Премахни дубликатите
				vd = (int(hours)*60 + int(minutes))*60 + int(seconds)
				if ((url.rsplit('/', 1)[1] in link) or ('type=' in url)): #Ако е правилното предаване или е новинарска емисия
					#addLink(name,url,vd,hd,plot,author,rating,ar,mode,iconimage)
					addLink(title,link,vd,'True',plot,'','','',3,cover)	
		xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_TITLE_IGNORE_THE) #Подреди списъка


#Зареждане на видео
def PLAY(url):
		if 'm3u8' in url:
			li = xbmcgui.ListItem(path=url+'|User-Agent='+urllib.parse.quote_plus(UA)+'&connection-timeout=930&verifypeer=false')
			#Разписание
			try:
				response = requests.get(base64.b64decode('aHR0cHM6Ly9hbmRyb21lZGEuZXUub3JnL3R2L25vdy5waHA/eG1sdHZpZD1iVFY='), headers=bp_headers, timeout=9)
				jsonrsp = response.json()
				#print jsonrsp['title']
				li.setInfo( type="Video", infoLabels={ 'Title': jsonrsp['title'], 'Plot': jsonrsp['description'] } )
				if (jsonrsp['cover'] != ''):
					li.setArt({ 'thumb': jsonrsp['cover'],'poster': jsonrsp['cover'], 'banner' : jsonrsp['cover'], 'fanart': jsonrsp['cover'], 'icon': jsonrsp['cover'] })
			except:
				pass
			try:
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
			except:
				xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('BTV PLUS','Телевизията не е достъпна за гледане', 4000, md+'DefaultIconError.png'))
		else:
			#xbmcgui.Dialog().ok('BTV+','bu+url'+"\n"+bu+url)
			response = requests.get(bu+url, headers=bp_headers)
			matcht = re.compile('<meta property=\"og:title\" content=\"(.+?)\" />').findall(response.text)
			for name in matcht:
				title = name
				plot = title
				matchl = re.compile('videoUrl = \'(.+?)\';').findall(response.text)
				for proforma in matchl:
					#xbmcgui.Dialog().ok('BTV+','bu+proforma'+"\n"+bu+proforma)
					response2 = requests.get(bu+proforma, headers=bp_headers)
					matchl2 = re.compile('src : \'(http.+?)\'').findall(response2.text)
					for adres in matchl2:
						link = adres.replace('\/','/')
						#xbmcgui.Dialog().ok('BTV+','link'+"\n"+link)
				try:
					matchc = re.compile('<link rel=\"image_src\" href="(.+?)\"').findall(response.text)
					for coverimage in matchc:
						cover = coverimage
					if 'https' in cover:
						cover = cover
					else:
						cover = 'https:'+cover
				except:
					cover = md+'DefaultMovies.png'
				
				try:
					stream = link+'|User-Agent='+urllib.parse.quote_plus(UA)+'&connection-timeout=930&verifypeer=false'
					li = xbmcgui.ListItem(path=stream)
					li.setArt({ 'thumb': cover,'poster': cover, 'banner' : cover, 'fanart': cover, 'icon': cover })
					li.setInfo( type="Video", infoLabels={ 'Title': title, 'Plot': plot } )
					xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
				except:
					xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('BTV PLUS','Видеото е премахнато!\nИма го във VOYO.BG', 4000, md+'DefaultIconError.png'))


#Гледане на живо
def LIVE(url):
		#xbmcgui.Dialog().ok('BTV+','Live Link ext'+"\n"+url)
		response = requests.get(url, headers=bp_headers)
		#print(response.text)
		matchl = re.compile('\"file\":\"(http.+?m3u8)').findall(response.text)
		for adres in matchl:
			link = adres.replace('\/','/')
			#xbmcgui.Dialog().ok('BTV+','Live Link int'+"\n"+link)
			PLAY(link)


#Гледане на живо
def LIVEG(url):
		response1 = requests.get('https://dai-api.bweb.bg:3000/get-token', headers=bp_headers)
		jsonrsp1 = response1.json()
		autorization = jsonrsp1['access_token']
		#xbmcgui.Dialog().ok('BTV+','Live Link autorization'+"\n"+jsonrsp1['access_token'])
		#Хедъри за заявки към услугата
		goo_headers = {
			'User-Agent': UA,
			'Accept': '*/*',
			'Content-Type': 'application/json',
			'DNT': '1',
			'Origin': bu,
			'Connection': 'keep-alive',
			'Sec-Fetch-Site': 'cross-site',
			'Sec-Fetch-Mode': 'cors',
			'Sec-Fetch-Dest': 'empty',
			'Referer': bu,
			'Accept-Language': 'bg-BG,bg;q=0.9,en;q=0.8',
			'Accept-Encoding': 'gzip',
			'Authorization': 'Bearer '+autorization
							}
		payload = {
			'live_config': 'projects/239117298520/locations/europe-west1/liveConfigs/btv-rmt-dai',
			'gam_settings': {
				'stream_id':'951fbecc-7c18-4a8d-b55e-ef84956ab3b1:GRQ'
			}
		}
		response2 = requests.post('https://videostitcher.googleapis.com/v1/projects/239117298520/locations/europe-west1/liveSessions', json=payload, headers=goo_headers)
		jsonrsp2 = response2.json()
		#xbmcgui.Dialog().ok('BTV+','Live Link URL'+"\n"+jsonrsp2['playUri'])
		PLAY(jsonrsp2['playUri'])


#Модул за добавяне на отделно заглавие и неговите атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLink(name,url,vd,hd,plot,author,rating,ar,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': iconimage })
		liz.setInfo( type="Video", infoLabels={ "title": name, "duration": vd, "plot": plot, "rating": ar, "studio": author, "mpaa": rating } )
		if hd=='True':
			liz.addStreamInfo('video', { 'width': 1280, 'height': 720 })
			liz.addStreamInfo('video', { 'aspect': 1.78, 'codec': 'h264' })
		else:
			liz.addStreamInfo('video', { 'width': 864, 'height': 480 })
			liz.addStreamInfo('video', { 'aspect': 1.78, 'codec': 'h264' })
		liz.addStreamInfo('audio', { 'codec': 'aac', 'channels': 2 })
		liz.setProperty("IsPlayable" , "true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok

#Модул за добавяне на отделна директория и нейните атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addDir(name,url,plot,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage, 'icon': 'DefaultFolder.png' })
		liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": plot } )
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok


#НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]
								
		return param



params=get_params()
url=None
name=None
iconimage=None
mode=None

try:
		url=urllib.parse.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.parse.unquote_plus(params["name"])
except:
		pass
try:
		name=urllib.parse.unquote_plus(params["iconimage"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass


#Списък на отделните подпрограми/модули в тази приставка - трябва напълно да отговаря на кода отгоре
if mode==None or url==None or len(url)<1:
		CATEGORIES()
	
elif mode==1:
		LISTALL(url)

elif mode==2:
		LISTEPISODES(url)

elif mode==3:
		PLAY(url)

elif mode==4:
		LIVE(url)

elif mode==5:
		LIVEG(url)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
