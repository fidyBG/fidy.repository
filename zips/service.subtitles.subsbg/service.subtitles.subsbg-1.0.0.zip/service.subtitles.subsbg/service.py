# SPDX-License-Identifier: MIT
"""SubsBG subtitle service for Kodi 19 and newer. No external dependencies."""
import json
import os
import re
import sys
import time
import uuid
from urllib.parse import parse_qsl, urlencode, unquote, urlsplit
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

API = 'https://subsbg.com/kodi.php'
ADDON = xbmcaddon.Addon()


def request(params, limit=1024 * 1024):
    req = Request(API + '?' + urlencode(params), headers={
        'User-Agent': 'SubsBG-Kodi/' + ADDON.getAddonInfo('version')})
    with urlopen(req, timeout=20) as response:
        data = response.read(limit + 1)
    if len(data) > limit:
        raise ValueError('Response too large')
    return data


def filename_only(path):
    # Never transmit credentials, stream query parameters or full local paths.
    path = path.split('|', 1)[0]
    if '://' in path:
        path = urlsplit(path).path
    return unquote(path.replace('\\', '/').rsplit('/', 1)[-1])[:512]


def parse_name(name):
    text = os.path.splitext(name)[0] if re.search(r'\.(mkv|mp4|avi|srt|m4v|ts)$', name, re.I) else name
    match = re.search(r'(?i)\bS(\d{1,3})E(\d{1,4})(?!\d)|\b(\d{1,3})x(\d{1,4})(?!\d)', text)
    if match:
        season, episode = (match.group(1), match.group(2)) if match.group(1) else (match.group(3), match.group(4))
        return {'type': 'tv', 'season': str(int(season)), 'episode': str(int(episode)),
                'query': re.sub(r'[._]+', ' ', text[:match.start()]).strip(' -')}
    year = re.search(r'\b((?:19|20)\d{2})\b', text)
    title = text[:year.start()] if year else re.split(r'(?i)\b(?:2160p|1080p|720p|WEBRip|WEB-DL|BluRay)\b', text)[0]
    return {'type': 'movie', 'query': re.sub(r'[._]+', ' ', title).strip(' -()[]'),
            'year': year.group(1) if year else ''}


def search_params(params):
    if params.get('action') == 'manualsearch':
        query = params.get('searchstring', '').strip()
        return parse_name(query) if query else {}
    label = lambda key: xbmc.getInfoLabel('VideoPlayer.' + key).strip()
    try:
        filename = filename_only(xbmc.Player().getPlayingFile())
    except Exception:
        filename = ''
    result = parse_name(filename)
    show, season, episode = label('TVShowTitle'), label('Season'), label('Episode')
    if show:
        result.update(type='tv', query=show, year='')
        if season.isdigit():
            result['season'] = season
        if episode.isdigit():
            result['episode'] = episode
    elif result['type'] == 'movie' and label('Title'):
        result['query'] = label('Title')
    if result['type'] == 'movie' and label('Year').isdigit():
        result['year'] = label('Year')
    imdb = label('IMDBNumber')
    if re.fullmatch(r'tt\d{5,12}', imdb):
        result['imdb'] = imdb
    result['filename'] = filename
    return result


def search(handle, params):
    query = search_params(params)
    if not query or not (query.get('query') or query.get('imdb')):
        xbmcgui.Dialog().notification('SubsBG', 'Използвай ръчно търсене: заглавие или Show S01E01.')
        return
    rows = json.loads(request(dict(query, action='search')).decode('utf-8'))['subtitles']
    if not rows:
        xbmcgui.Dialog().notification('SubsBG', 'Няма намерени субтитри. Опитай ръчно търсене.')
    for row in rows:
        subtitle_id = int(row['id'])
        item = xbmcgui.ListItem(label='Bulgarian', label2=row['title'] + ' · ' + row['release'])
        item.setArt({'thumb': os.path.join(ADDON.getAddonInfo('path'), 'resources', 'flag.png')})
        # Filename similarity is not proof of synchronization.
        item.setProperty('sync', 'false')
        item.setProperty('hearing_imp', 'false')
        xbmcplugin.addDirectoryItem(handle=handle, url=sys.argv[0] + '?' + urlencode({
            'action': 'download', 'id': subtitle_id}), listitem=item, isFolder=False)


def download(handle, params):
    subtitle_id = params.get('id', '')
    if not re.fullmatch(r'[1-9]\d{0,9}', subtitle_id):
        raise ValueError('Invalid subtitle ID')
    data = request({'action': 'download', 'id': subtitle_id}, 2 * 1024 * 1024)
    if not data or b'-->' not in data or data.lstrip().startswith((b'<html', b'<!DOCTYPE', b'{')):
        raise ValueError('Invalid subtitle file')
    folder = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    os.makedirs(folder, exist_ok=True)
    for name in os.listdir(folder):
        if re.fullmatch(r'subsbg-[a-f0-9]{32}\.bg\.srt', name):
            path = os.path.join(folder, name)
            try:
                if time.time() - os.path.getmtime(path) > 7 * 86400:
                    os.remove(path)
            except OSError:
                pass
    path = os.path.join(folder, 'subsbg-' + uuid.uuid4().hex + '.bg.srt')
    with open(path, 'wb') as output:
        output.write(data)
    xbmcplugin.addDirectoryItem(handle=handle, url=path, listitem=xbmcgui.ListItem(label=path), isFolder=False)


def run():
    handle = int(sys.argv[1])
    params = dict(parse_qsl(sys.argv[2].lstrip('?'))) if len(sys.argv) > 2 else {}
    succeeded = True
    try:
        if params.get('action') in ('search', 'manualsearch'):
            search(handle, params)
        elif params.get('action') == 'download':
            download(handle, params)
    except Exception as error:
        succeeded = False
        xbmc.log('SubsBG: ' + type(error).__name__, xbmc.LOGERROR)
        xbmcgui.Dialog().notification('SubsBG', 'Неуспешна връзка или изтегляне. Опитай отново.', xbmcgui.NOTIFICATION_ERROR)
    finally:
        xbmcplugin.endOfDirectory(handle, succeeded=succeeded)


if __name__ == '__main__':
    run()
