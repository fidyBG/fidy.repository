# -*- coding: utf-8 -*-
import os
import re
import sys
import xbmc, xbmcplugin, xbmcgui, xbmcaddon
import urllib
import requests
import xbmcvfs
from datetime import datetime
from bs4 import BeautifulSoup
from urllib.parse import urlparse, parse_qs
import urllib.parse
import hashlib

__addon__ = xbmcaddon.Addon()
__icon__ = __addon__.getAddonInfo('icon')
__cwd__ = xbmcvfs.translatePath(__addon__.getAddonInfo('path'))
__profile__ = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__icon_search__ = xbmcvfs.translatePath(os.path.join(__cwd__, 'resources', 'search.png'))
__icon_clear__ = xbmcvfs.translatePath(os.path.join(__cwd__, 'resources', 'clear.png'))
__icon_folders__ = xbmcvfs.translatePath(os.path.join(__cwd__, 'resources', 'movies.png'))
__icon_sresult__ = xbmcvfs.translatePath(os.path.join(__cwd__, 'resources', 'search-result.png'))
__icon_emptyfolder__ = xbmcvfs.translatePath(os.path.join(__cwd__, 'resources', 'empty.png'))

searchlist = __addon__.getSetting('searchlist')


def Notify(msg1, msg2):
    xbmc.executebuiltin((u'Notification(%s,%s,%s,%s)' % (msg1, msg2, '5000', __icon_folders__)))


if __addon__.getSetting('firstrun') == 'true':
    Notify('Грешка!', 'Проверете настройките.')
    __addon__.openSettings()
    __addon__.setSetting('firstrun', 'false')

if __addon__.getSetting('bg_aud') == 'true':
    bs = '&bgaudio=1'
else:
    bs = ''

if __addon__.getSetting('xxx') == 'true':
    xxx = True
else:
    xxx = False

if not __addon__.getSetting('username'):
    Notify('Потребител', 'празно')
if not __addon__.getSetting('password'):
    Notify('Парола', 'празно')

usr = __addon__.getSetting('username'),
passwd = __addon__.getSetting('password')

__categories__ = [
    {'cat_ids': '60', 'cat_name': u'Филми 4K'},
    {'cat_ids': '18', 'cat_name': u'Филми HDTV'},
    {'cat_ids': '59', 'cat_name': u'Филми VHS'},
    {'cat_ids': '11', 'cat_name': u'Филми DVD-R'},
    {'cat_ids': '1', 'cat_name': u'Филми DVD Rip'},
    {'cat_ids': '58', 'cat_name': u'Филми x265'},
    {'cat_ids': '34', 'cat_name': u'Български Филми'},
    {'cat_ids': '24', 'cat_name': u'Български Сериали'},
    {'cat_ids': '14;15', 'cat_name': u'Сериали'},
    {'cat_ids': '5', 'cat_name': u'Формула 1'},
    {'cat_ids': '57', 'cat_name': u'Формула 2'}
]

UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'
headers_new = {'user-agent': UA,
               'referer': 'https://www.p2pbg.com/',
               'host': 'www.p2pbg.com'
               }

s = requests.Session()

baseurl = 'https://www.p2pbg.com'
loginurl = '/login'
categoryurl = baseurl + '/torrents?category='
subpage = baseurl + '/torrents/'

if xxx == True:
    __categories__ += [
        {'cat_ids': '13;32;48;53;54', 'cat_name': u'XXX'}
    ]

    torrentsurl = baseurl + '/torrents?category=1;5;7;11;14;15;16;17;18;24;34;35;58;59;60;51;13;32;48;53;54;57&active=1&hidexxx=off' + bs
else:
    torrentsurl = baseurl + '/torrents?category=1;5;7;11;14;15;16;17;18;24;34;35;58;59;60;51;57&active=1&hidexxx=on' + bs

# взимаме token
r = s.get(baseurl, headers=headers_new)
data_token = r.text

match_token = re.search('token".+?"(.+?)"', data_token)

if match_token:
    token = match_token.group(1)
else:
    token = ''

values = {'_token': token,
          'returnto': '',
          'uid': usr,
          'pwd': passwd}

r = s.post(baseurl + loginurl, data=values, headers=headers_new)


def find_info_hash(data):
    marker = b"4:info"
    idx = data.find(marker)

    if idx == -1:
        return None

    info_start = idx + len(marker)
    pos = info_start

    if data[pos:pos + 1] != b'd':
        return None

    depth = 0
    while pos < len(data):
        c = data[pos:pos + 1]
        if c == b'd' or c == b'l':
            depth += 1
            pos += 1
        elif c == b'e':
            depth -= 1
            pos += 1
            if depth == 0:
                break
        elif c == b'i':
            end = data.index(b'e', pos + 1)
            pos = end + 1
        elif c in b'0123456789':
            colon = data.index(b':', pos)
            length = int(data[pos:colon])
            pos = colon + 1 + length
        else:
            pos += 1

    info_bytes = data[info_start:pos]
    return hashlib.sha1(info_bytes).hexdigest()


def torrent_url_to_magnet(torrent_data, name="", session=None):
    try:
        info_hash = find_info_hash(torrent_data)
        if not info_hash:
            return None
        magnet = f"magnet:?xt=urn:btih:{info_hash}&dn={name}"

        return magnet
    except Exception as e:
        return None

def CATEGORIES():
    FilmiYear = int(datetime.now().date().strftime("%Y"))

    addDir(u'Търсене', torrentsurl + '&search=', 4, '', __icon_search__)
    addDir(u'Последно добавени', torrentsurl, 1, '', __icon_folders__)
    addDir(u'Филми от ' + str(FilmiYear) + u' година', torrentsurl + '&search=' + str(FilmiYear), 1, '',
           __icon_folders__)
    addDir(u'Филми от ' + str(FilmiYear - 1) + u' година', torrentsurl + '&search=' + str(FilmiYear - 1), 1, '',
           __icon_folders__)
    addDir(u'Филми от ' + str(FilmiYear - 2) + u' година', torrentsurl + '&search=' + str(FilmiYear - 2), 1, '',
           __icon_folders__)

    for cat in __categories__:
        addDir(cat['cat_name'], categoryurl + cat['cat_ids'] + bs, 1, '', __icon_folders__)


def INDEXPAGES(name, url):
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')

    r = s.get(url, headers=headers_new)

    data = r.text

    soup = BeautifulSoup(data, 'html.parser')

    target_table = next(
        (
            t for t in soup.find_all("table")
            if t.get("width") == "100%"
               and t.get("class") == ["lista"]
               and len(t.attrs) == 2
        ),
        None
    )

    if not target_table:
        target_table = next(
            (
                t for t in soup.find_all("table")
                if t.get("class") == ["torrent-index__table"]
                   and len(t.attrs) == 1
            ),
            None
        )

    if target_table:
        rows = target_table.find_all("tr")

        for row in rows:
            desk = ''
            imdb_id = ''

            cols = row.find_all("td")

            if len(cols) < 3:
                continue

            # Magnet
            #magnet_tag = cols[1].find("a", href=True)

            magnet = None
            #for a in cols[1].find_all("a", href=True):
            #    if "magnet:?" in a["href"]:
            #        magnet = a["href"]
            #        break

            #if not magnet:
            #    continue

            # Линк "Свали"
            #download = cols[2].find("a")["href"]

            #if not download:
            #    continue
            download_match = re.search("showPreview\('(.+?)'", str(row))
            if not download_match:
                continue

            download = subpage + download_match.group(1)

            # --- IMDB ID и описание на филма/сериала ---
            r_page = s.get(download, headers=headers_new)
            data_page = r_page.text

            match_imdb_id = re.search(u'imdb.+?(tt.+?)/', data_page)
            if match_imdb_id:
                imdb_id = match_imdb_id.group(1)

            magnet_match = re.search('https://www.p2pbg.com/download.php.+?.torrent', data_page)

            if not magnet_match:
                continue

            torrent_url = magnet_match.group(0)

            # Заглавие на английски
            # match_eng = re.search(u'Заглавие на Английски.+?fieldValue">(.+?)<', data_page)
            # if match_eng:
            #    title = match_eng.group(1)
            # else:
            title = cols[1].find("a", onclick=True).get_text(strip=True)

            # --- Година на филма ---
            match_year = re.search(u'Година.+?(\d{4})', data_page)
            if match_year:
                year = match_year.group(1)
            else:
                year = ''

            # Жанр
            match_genre = re.search(u'Жанр.+?fieldValue">(.+?)<', data_page)

            if not match_genre:
                match_genre = re.search(u'Жанр.+?class="torrent-preview-fact__value">(.+?)<', data_page)

            if match_genre:
                genre = match_genre.group(1)
            else:
                genre = ''

            # Релийз
            match_release = re.search(u'Релийз.+?fieldValue">(.+?)<', data_page)

            if not match_release:
                match_release = re.search(u'Релийз.+?class="torrent-preview-fact__value">(.+?)<', data_page)

            if match_release:
                release = match_release.group(1)
            else:
                release = ''

            # Видео поток
            match_potok = re.search(u'Видео поток.+?fieldValue">(.+?)<', data_page)
            if match_potok:
                potok = match_potok.group(1)
            else:
                potok = ''

            # Резюме
            match_resume = re.search(u'Резюме.+?fieldValue">(.+?)<', data_page)

            if not match_resume:
                match_resume = re.search(u'Резюме.+?class="torrent-preview-fact__value">(.+?)<', data_page)

            if match_resume:
                resume = match_resume.group(1)
            else:
                resume = ''

            # SIZE
            size = cols[6].get_text(strip=True)

            # SEEDS
            seeds = int(cols[7].get_text(strip=True))

            # LEECHES
            leeches = int(cols[8].get_text(strip=True))

            # --- BG Subs ---
            bg_subs = "Да" if row.find("img", src=lambda x: x and x.endswith("subs.gif")) else "Не"

            # --- BG Audio ---
            bg_audio = "Да" if row.find("img", src=lambda x: x and x.endswith("bgaudio.gif")) else "Не"

            if release != '':
                desk = desk + '[COLOR CC00FF00]Релийз: [/COLOR]' + str(release) + '\n'

            if potok != '':
                desk = desk + '[COLOR CC00FF00]Видео поток: [/COLOR]' + str(potok) + '\n'

            desk = desk + '[COLOR CC00FF00]Seeders: [/COLOR]' + str(
                seeds) + ' [COLOR CC00FF00]Leechers: [/COLOR]' + str(leeches) + '\n'
            desk = desk + '[COLOR CC00FF00]Размер: [/COLOR]' + str(size) + '\n'

            if year != '':
                desk = desk + '[COLOR CC00FF00]Година: [/COLOR]' + str(year) + '\n'

            if genre != '':
                desk = desk + '[COLOR CC00FF00]Жанр: [/COLOR]' + str(genre) + '\n'

            desk = desk + '[COLOR CC00FF00]БГ субтитри: [/COLOR]' + str(bg_subs) + '\n'
            desk = desk + '[COLOR CC00FF00]БГ аудио: [/COLOR]' + str(bg_audio)

            if resume != '':
                desk = desk + '\n\n[COLOR CC00FF00]Резюме: [/COLOR]' + str(resume)

            image_url = None

            for a in row.find_all("a", onmouseover=True):
                if "img src=" in a["onmouseover"]:
                    match = re.search(r"img src=([^ >]+)", a["onmouseover"])
                    if match:
                        image_url = match.group(1)
                        break

            if not image_url:
                match = re.search('data-overlib=\'&lt;img src="(.+?)"', str(row))
                if match:
                    image_url = match.group(1)

            # if bg_subs == 'Да':
            #    title = title + '[COLOR CC00FF00] | БГ субтитри[/COLOR]'

            # if bg_audio == 'Да':
            #    title = title + '[COLOR CC00FF00] | БГ аудио[/COLOR]'

            #r_magnet = s.get(torrent_url, headers=headers_new)
            #torrent_data = r_magnet.content

            #magnet = torrent_url_to_magnet(torrent_data, name=title)

            addLink(title, torrent_url, 2, desk, image_url, imdb_id)

        # Следваща страница
        next_page = None

        for a in soup.find_all("a", href=True):
            if a.get_text(strip=True) == ">":
                next_page = a["href"]
                break
        if next_page:
            addDir('[COLOR CC00FF00][B]Следваща страница >>>[/B][/COLOR]', next_page, 1, '', '')
    else:
        pass


# Търсачка
def SEARCH(url):
    keyb = xbmc.Keyboard('', 'Търсачка')
    keyb.doModal()
    searchText = ''
    if (keyb.isConfirmed()):
        searchText = urllib.parse.quote_plus(keyb.getText())
        searchText = searchText

        searchText = searchText.replace('+', ' ')
        INDEXPAGES('Търсачка', url + searchText)
    else:
        CATEGORIES()


def PLAY(torrent_url):
    use_torrserve = __addon__.getSetting('player') == '1'  # беше addon, трябва __addon__

    r = s.get(torrent_url, headers=headers_new)
    torrent_data = r.content

    if use_torrserve:
        magnet = torrent_url_to_magnet(torrent_data, name=name)
        if magnet:
            p = 'plugin://plugin.video.torrserve/?action=gotInfo&magnet={}'.format(
                urllib.parse.quote_plus(magnet)
            )
            xbmc.executebuiltin('Container.Update({})'.format(p))
        else:
            xbmc.executebuiltin("Notification('Грешка!','Неуспешно извличане на магнитен линк.')")
    else:
        if not xbmcvfs.exists(__profile__):
            xbmcvfs.mkdirs(__profile__)

        torrent_path = os.path.join(__profile__, "elementum_temp.torrent")

        f = xbmcvfs.File(torrent_path, 'wb')
        f.write(bytearray(torrent_data))
        f.close()

        uri = urllib.parse.quote_plus(torrent_path)
        elementum_url = f'plugin://plugin.video.elementum/play?uri={uri}'

        li = xbmcgui.ListItem(path=elementum_url)
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': name})
        try:
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
        except:
            xbmc.executebuiltin("Notification('Грешка!','Видеото липсва на сървъра.')")

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


def addDir(name, url, mode, plot, iconimage):
    u = sys.argv[0] + "?url=" + urllib.parse.quote_plus(url) + "&mode=" + str(
        mode) + "&name=" + urllib.parse.quote_plus(name) + "&iconimage=" + urllib.parse.quote_plus(iconimage)
    liz = xbmcgui.ListItem(name)

    ok = True
    liz.setArt({'thumb': iconimage, 'poster': iconimage, 'banner': iconimage, 'fanart': iconimage})
    liz.setInfo(type="Video", infoLabels={"Title": name, "plot": plot})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok


def addLink(name, url, mode, plot, iconimage, imdb_id):
    u = sys.argv[0] + "?url=" + urllib.parse.quote_plus(url) + "&mode=" + str(
        mode) + "&name=" + urllib.parse.quote_plus(name)
    liz = xbmcgui.ListItem(name)

    ok = True
    liz.setArt({'thumb': iconimage, 'poster': iconimage, 'banner': iconimage, 'fanart': iconimage})
    liz.setInfo(type="Video", infoLabels={"Title": name, "plot": plot, 'IMDBNumber': imdb_id})
    liz.setProperty('fanart_image', iconimage)
    liz.setProperty("IsPlayable", "true")
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
    return ok


params = get_params()
url = None
name = None
iconimage = None
mode = None
count = None
groupID = None
ytpass = None

try:
    url = urllib.parse.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.parse.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.parse.unquote_plus(params["iconimage"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass
try:
    count = int(params["count"])
except:
    pass
try:
    groupID = int(params["groupID"])
except:
    pass
try:
    ytpass = urllib.parse.unquote_plus(params["ytpass"])
except:
    pass

if mode == None or url == None or len(url) < 1:
    print("")
    CATEGORIES()

elif mode == 4:
    print("" + url)
    SEARCH(url)

elif mode == 1:
    print("" + url)
    INDEXPAGES(name, url)

elif mode == 2:
    print("" + url)
    PLAY(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))