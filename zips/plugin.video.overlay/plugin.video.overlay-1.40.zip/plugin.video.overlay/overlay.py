import xbmc
import xbmcgui
import subprocess
import time

def format_audio_codec(raw_codec):
    if not raw_codec:
        return "N/A"

    codec = raw_codec.lower()
    profile = xbmc.getInfoLabel("VideoPlayer.AudioProfile").lower()

    if "truehd" in codec:
        if "atmos" in codec or "atmos" in profile:
            return "TrueHD + Atmos"
        return "TrueHD"
    elif "eac3" in codec or "e-ac-3" in codec or "ddp" in codec:
        if "atmos" in codec or "atmos" in profile:
            return "Dolby Digital Plus + Atmos"
        return "Dolby Digital Plus"
    elif "ac3" in codec:
        return "Dolby Digital"

    elif "dts" in codec or "dca" in codec:
        if any(x in codec for x in ["dtsx", "dts:x", "_x", "_x_", "dtshd_ma_x"]) or "x" in profile:
            if "imax" in codec or "imax" in profile:
                return "DTS:X IMAX"
            return "DTS:X"
        elif "ma" in codec or "hd_ma" in codec:
            return "DTS-HD MA"
        elif "hd" in codec:
            return "DTS-HD"
        return "DTS"

    elif "aac" in codec:
        return "AAC"
    elif "flac" in codec:
        return "FLAC"
    elif "pcm" in codec:
        return "PCM"
    elif "mp3" in codec:
        return "MP3"
    elif "opus" in codec:
        return "Opus"

    return raw_codec.upper()
    

def get_cpu_usage():
    """Среден CPU % (общо / брой ядра)"""
    try:
        cpu_line = xbmc.getInfoLabel("System.CPUUsage") or ""
        if cpu_line:
            parts = cpu_line.split()
            per_core = [int(p.rstrip('%')) for p in parts if p.endswith('%')]
            if per_core:
                average = sum(per_core) / len(per_core)
                return f"{average:.1f}%"
    except:
        pass
    try:
        output = subprocess.check_output("top -bn1 | grep 'Cpu(s)' | awk '{print $2}'", shell=True).decode().strip()
        return output + "%" if output else "N/A"
    except:
        return "N/A"

def get_temperature():
    """Температура от /sys (за Amlogic/CoreELEC)"""
    try:
        output = subprocess.check_output("cat /sys/class/thermal/thermal_zone0/temp", shell=True).decode().strip()
        temp = int(output) / 1000 if output.isdigit() else 0
        return f"{temp}°C" if temp > 0 else "N/A"
    except:
        return "N/A"

def get_cpu_frequency():
    """Честота на CPU (MHz) от /sys (за Amlogic/CoreELEC)"""
    try:
        output = subprocess.check_output("cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_cur_freq", shell=True).decode().strip()
        freq = int(output) / 1000 if output.isdigit() else 0
        return f"{freq/1000:.1f} GHz" if freq > 0 else "N/A"
    except:
        return "N/A"

def instant_overlay():
    try:
        display_res = xbmc.getInfoLabel("System.ScreenResolution") or "N/A"
        mem_used = xbmc.getInfoLabel("System.Memory(used)") or "N/A"
        mem_total = xbmc.getInfoLabel("System.Memory(total)") or "N/A"

        video_width = xbmc.getInfoLabel("Player.Process(videowidth)") or "N/A"
        video_height = xbmc.getInfoLabel("Player.Process(videoheight)") or "N/A"
        video_fps = xbmc.getInfoLabel("Player.Process(videofps)") or "N/A"
        video_bitrate = xbmc.getInfoLabel("VideoPlayer.VideoBitrate") or "N/A"
        raw_audio_codec = xbmc.getInfoLabel("VideoPlayer.AudioCodec") or "N/A"
        audio_codec = format_audio_codec(raw_audio_codec)
        audio_channels = xbmc.getInfoLabel("VideoPlayer.AudioChannels") or "N/A"
        audio_lang = xbmc.getInfoLabel("VideoPlayer.AudioLanguage") or "N/A"
        audio_bitrate = xbmc.getInfoLabel("VideoPlayer.AudioBitrate") or "N/A"

        hdr_type = xbmc.getInfoLabel("VideoPlayer.HDRType") or ""
        hdr_display = "SDR"
        if hdr_type:
            hdr_type = hdr_type.lower()
            if "dolby" in hdr_type:
                hdr_display = "Dolby Vision"
            elif "hdr10+" in hdr_type or "hdr10plus" in hdr_type:
                hdr_display = "HDR10+"
            elif "hdr10" in hdr_type:
                hdr_display = "HDR10"
            elif "hlg" in hdr_type:
                hdr_display = "HLG"
            else:
                hdr_display = hdr_type.upper()

        cpu_freq = get_cpu_frequency()

        progress = xbmcgui.DialogProgress()
        progress.create("• Информация за системата •")

        cycle_count = 0
        while True:
            cycle_count += 1

            mem_used = xbmc.getInfoLabel("System.Memory(used)") or "N/A"
            mem_total = xbmc.getInfoLabel("System.Memory(total)") or "N/A"
            mem_percent = xbmc.getInfoLabel("System.Memory(used.percent)") or "N/A"
            cpu_percent = get_cpu_usage()
            temp = get_temperature()

            message = f"Екран: {display_res}"
            if video_width != "N/A":
                message += f"\nВидео: {hdr_display} - {video_width}x{video_height}p - {video_fps} FPS"
                if video_bitrate != "N/A":
                    message += f" - {video_bitrate} kb/s"
            message += f"\nАудио: {audio_codec} - {audio_channels} ch - {audio_lang}"
            if audio_bitrate != "N/A":
                message += f" - {audio_bitrate} kb/s"
            message += f"\nПамет: {mem_used} от {mem_total} - {mem_percent}"

            progress.update(500, message)
            xbmc.sleep(100)

            if progress.iscanceled():
                break

        progress.close()

    except Exception as e:
        xbmc.log(f"[Overlay Manual Error] {str(e)}", xbmc.LOGERROR)

if __name__ == '__main__':
    instant_overlay()