# -*- coding: utf-8 -*-

from nsub import log_my, savetofile, list_key
from common import *
import requests
import re
try:
  import urllib.request
except:
  pass
import json
import io
import re
import requests

s = requests.Session()

values = {'s': '','w': 'name','category':''}

headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
'Accept-Encoding': 'gzip, deflate',
'Accept-Language': 'en-US,en;q=0.9,bg-BG;q=0.8,bg;q=0.7,ru;q=0.6',
'Connection': 'keep-alive',
'Host': 'subsland.com',
'Referer': 'https://subsland.com/',
'Upgrade-Insecure-Requests': '1',
'User-Agent': 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36'}

url = 'subsland.com'
url_full = 'https://subsland.com'

def get_id_url_n(txt, list, epizode):
  data = txt.replace('\t','').replace('\n','').replace('\r','')

  if re.search('Не са открити,', data):
      pass
  else:
      match = re.compile('<td align="left"><a href=(.+?) .+?<b>(.+?)</b>.+?"UnTip\(\)" >(.+?)</a>.+?<a href=.+?>.+?<a href=(.+?) onMouseover').findall(data)
      for link, release, title, ziplink in match:
        #за сериали
        findTVShow = re.search('(s\d\de\d\d)', title.lower())
        if findTVShow:
            checkepizode = findTVShow.group(1)
        else:
            checkepizode = ''

        if checkepizode.lower() == epizode.lower():
            findB = re.search('\<\/b\>', release)
            if findB:
                info = title
            else:
                info = title + ' / ' + release.replace('&lt;br&gt;', ' / ')

            try:
                tempurl = ziplink.encode('utf-8', 'replace').decode('utf-8')
                list.append({'url': tempurl,
                          'FSrc': '[COLOR CC00FF00][B][I](subsland) [/I][/B][/COLOR]',
                          'info': info.encode('utf-8', 'replace').decode('utf-8'),
                          'year': '',
                          'cds': '',
                          'fps': '',
                          'rating': '0.0',
                          'id': __name__})
            except:
                tempurl = ziplink.encode('utf-8', 'replace')
                list.append({'url': tempurl,
                          'FSrc': '[COLOR CC00FF00][B][I](subsland) [/I][/B][/COLOR]',
                          'info': info.encode('utf-8', 'replace'),
                          'year': '',
                          'cds': '',
                          'fps': '',
                          'rating': '0.0',
                          'id': __name__})
        else:
            pass
  return

def get_data(l, key):
  out = []
  for d in l:
    out.append(d[key])
  return out

def read_sub (mov):
  list = []
  log_my(mov)

  values['s'] = mov

  #за сериали
  findTVShow = re.search('(s\d\de\d\d)', mov.lower())

  if findTVShow:
      epizode = findTVShow.group(1)
  else:
      epizode = ''

  try:
      enc_values = urllib.parse.urlencode(values)
  except:
      enc_values = urllib.urlencode(values)
  
  log_my('Url: ', (url), 'Headers: ', (headers), 'Values: ', (enc_values))

  try:
    r = s.get(url_full+"/index.php?"+enc_values, headers=headers, timeout=10)
    data = r.text
  except:
    return None

  get_id_url_n(data, list, epizode)
  if run_from_xbmc == False:
    for k in list_key:
      d = get_data(list, k)
      log_my(d)

  return list

def get_sub(id, sub_url, filename):
  s = {}

  matchname = sub_url.split('/')

  link = sub_url

  r = requests.get(link)

  data = r.content

  s['data'] = data
  s['fname'] = matchname[len(matchname)-1]
  return s