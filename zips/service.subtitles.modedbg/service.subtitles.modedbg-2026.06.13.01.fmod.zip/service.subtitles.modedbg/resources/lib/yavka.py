# -*- coding: utf-8 -*-

from nsub import log_my, savetofile, list_key
from common import *
import requests
import re
try:
  import urllib.request
except:
  pass
import json
import io

s = requests.Session()

#values = {'s': '','y': '','c': '','u':'', 'l': 'BG','g': '', 'i': '', 'search': ' Търсене'}
values = {'sea': '','y': '','c': '','u':'', 'l': 'BG','g': '', 'i': '', 'cf-turnstile-response': '', 'search': ' Търсене'}

headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Accept-Language': 'en-US,en;q=0.9',
            'cache-control': 'max-age=0',
            'content-length': '111',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://yavka.net',
            'priority': 'u=0, i',
            'Referer': 'https://yavka.net/search',
            'sec-ch-ua': '"Not;A=Brand";v="24", "Chromium";v="128"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'}

url = 'yavka.net'
url_full = 'https://yavka.net'

def get_id_url_n(txt, list):
  soup = BeautifulSoup(txt, 'html.parser')
  # dump_src(soup, 'src.html')
  for link in soup.findAll("a", {"class": "balon"}): 
    info = link.text

    f_info = re.search('vspace.+?\-\&gt;(.+?)\&lt;', str(link))

    yr = link.find_next_sibling('span', text=True)
    yr = yr.text.replace('(','').replace(')','')

    if f_info:
        s_info = '#' + f_info.group(1)
        t_info = s_info.replace('# ', '').replace('#', '')
        fo_info = info.encode('utf-8', 'replace').decode('utf-8') + ' (' + yr + ')' + '\n' + t_info
    else:
        f_info = re.search('vspace.+?\&gt;(.+?)\&lt;', str(link))

        if f_info:
            s_info = '#' + f_info.group(1)
            t_info = s_info.replace('# ', '').replace('#', '')
            fo_info = info.encode('utf-8', 'replace').decode('utf-8') + ' (' + yr + ')' + '\n' + t_info
        else:
            fo_info = info.encode('utf-8', 'replace').decode('utf-8') + ' (' + yr + ')'

    fps = link.find_all_next(string=True)[6].strip()
    try:
        tempurl = '/'+link['href'].encode('utf-8', 'replace').decode('utf-8')
        list.append({'url': tempurl.replace('//','/'),
                  'FSrc': '[COLOR CC00FF00][B][I](yavka) [/I][/B][/COLOR]',
                  'info': fo_info,
                  'year': yr.encode('utf-8', 'replace').decode('utf-8'),
                  'cds': '',
                  'fps': fps.encode('utf-8', 'replace').decode('utf-8'),
                  'rating': 0,
                  'id': __name__})
    except:
        tempurl = '/'+link['href'].encode('utf-8', 'replace')
        list.append({'url': tempurl.replace('//','/'),
                  'FSrc': '[COLOR CC00FF00][B][I](yavka) [/I][/B][/COLOR]',
                  'info': info.encode('utf-8', 'replace'),
                  'year': yr.encode('utf-8', 'replace'),
                  'cds': '',
                  'fps': fps.encode('utf-8', 'replace'),
                  'rating': 0,
                  'id': __name__})
  return

def get_data(l, key):
  out = []
  for d in l:
    out.append(d[key])
  return out

def read_sub (mov, year):
  list = []
  log_my(mov, year)

  if re.search('Season \d\d', mov) or re.search('season \d\d', mov):
      mov = mov.replace('Season ', 's').replace('season ', 's')
  elif re.search('Season \d', mov) or re.search('season \d', mov):
      mov = mov.replace('Season ', 's0').replace('season ', 's0')
  else:
      pass

  values['sea'] = mov
  values['y'] = year
  
  try:
      enc_values = urllib.parse.urlencode(values)
  except:
      enc_values = urllib.urlencode(values)

  log_my('Url: ', (url), 'Headers: ', (headers), 'Values: ', (enc_values))

  try:
    r = s.post(url_full+"/search", data=enc_values, headers=headers)
    data = r.text
  except:
    return None

  get_id_url_n(data, list)
  if run_from_xbmc == False:
    for k in list_key:
      d = get_data(list, k)
      log_my(d)

  return list

def get_sub(id, sub_url, filename):
    headers_get = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Accept-Language': 'bg,en-US;q=0.9,en;q=0.8',
        'Referer': 'https://yavka.net/searc',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36'}
    ss = requests.Session()
    rID = ss.get(url_full + sub_url, headers=headers_get)
    #findID = re.search('name="id" value="(.+?)"', rID.text)
    findID = re.compile('type="hidden" name="(.+?)" value="(.+?)"').findall(rID.text)

    s = {}
    tsplit = sub_url.split('/')
    if findID:
        counID = 1
        for nam, val in findID:
            if counID == 1:
                nam1 = nam
                val1 = val
                counID = counID + 1
            elif counID == 2:
                nam2 = nam
                val2 = val
                counID = counID + 1
            else:
                pass
        tvalues = {nam1: val1,
                   nam2: val2}
    else:
        ID = tsplit[2]
        tvalues = {'id': ID,
                   'lng': tsplit[3] }

    try:
      enc_values = urllib.parse.urlencode(tvalues).encode("utf-8")
    except:
      enc_values = urllib.urlencode(tvalues)
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Accept-Language': 'bg,en-US;q=0.9,en;q=0.8',
        'cache-control': 'max-age=0',
        'content-length': '209',
        'content-type': 'application/x-www-form-urlencoded',
        'dnt': '1',
        'origin': 'https://yavka.net',
        'Referer': url_full + sub_url,
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36'}

    rzip = ss.post(url_full + sub_url + '/', data=tvalues, headers=headers)
    data = rzip.content

    matchName = re.search('filename="(.+?)"', str(rzip.headers))
    name = matchName.group(1)

    s['data'] = data
    s['fname'] = name
    return s