# -*- coding: utf-8 -*-

from nsub import log_my, savetofile, list_key
from common import *
import requests
import re
try:
    import urllib.request
except:
    pass
import json

s = requests.Session()

headers = {
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'en-US,en;q=0.9',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
    'Referer': 'https://bayflix.sb/',
}

url_full = 'https://bayflix.sb'


def _extract_fps(description):
    m = re.search(r'FPS:\s*([\d.]+)', description or '')
    return m.group(1) if m else ''


def _extract_cds(description):
    m = re.search(r'CDs?:\s*(\d+)', description or '')
    return m.group(1) if m else ''


def _extract_releases(description):
    releases = []
    for line in (description or '').splitlines():
        line = line.strip()
        if not line:
            break
        if re.match(r'^FPS:', line, re.IGNORECASE):
            break
        # Only include lines that look like release names (dots, no colon)
        if '.' in line and ':' not in line and re.match(r'^[\w\[\](). +-]+$', line):
            releases.append(line)
    return releases


def _parse_episode(text):
    # Matches S01E01 / s01e01
    m = re.search(r'[Ss](\d{1,2})[Ee](\d{1,2})', text)
    if m:
        return 's%02de%02d' % (int(m.group(1)), int(m.group(2)))
    # Matches 01x01 / 1x1
    m = re.search(r'(\d{1,2})x(\d{1,2})', text)
    if m:
        return 's%02de%02d' % (int(m.group(1)), int(m.group(2)))
    return None


def _matches_episode(item, mov):
    wanted = _parse_episode(mov)
    if not wanted:
        return True  # movie — no episode filtering

    # Check release_name list
    for rname in (item.get('release_name') or []):
        if _parse_episode(rname) == wanted:
            return True

    # Check description lines (release names embedded there)
    desc = item.get('description') or ''
    for line in desc.splitlines():
        if _parse_episode(line) == wanted:
            return True

    return False


def read_sub(mov, year):
    result = []
    log_my(mov, year)

    # Strip episode pattern from search title for TV shows
    search_title = re.sub(r'\s+[Ss]\d{1,2}[Ee]\d{1,2}.*$', '', mov).strip()
    search_title = re.sub(r'\s+\d{1,2}x\d{1,2}.*$', '', search_title).strip()

    try:
        enc_title = urllib.parse.quote(search_title)
    except:
        enc_title = urllib.quote(search_title)

    log_my('bayflix search:', search_title)

    try:
        r = s.get(url_full + '/api/subtitles/search?title=' + enc_title, headers=headers, timeout=15)
        data = r.json()
    except Exception as e:
        log_my('bayflix.read_sub error:', str(e))
        return None

    if not data:
        return None

    for item in data:
        # Filter by year for movies
        if year and item.get('media_type') == 'movie':
            release_year = (item.get('release_date') or '')[:4]
            if release_year and abs(int(release_year) - int(year)) > 1:
                continue

        # Filter by episode for TV shows
        if not _matches_episode(item, mov):
            continue

        sub_url = item.get('subtitle_link') or ''
        if not sub_url:
            sub_url = url_full + '/api/subtitles/download/' + item.get('_id', '')
        desc = item.get('description') or ''
        title = item.get('title', '')
        fps = _extract_fps(desc)
        cds = _extract_cds(desc)

        releases = _extract_releases(desc)
        if releases:
            info = title + '\n' + '\n'.join(releases)
        else:
            info = title

        try:
            result.append({
                'url': sub_url,
                'FSrc': '[COLOR CC00FF00][B][I](bayflix) [/I][/B][/COLOR]',
                'info': info.encode('utf-8', 'replace').decode('utf-8'),
                'year': (item.get('release_date') or '')[:4],
                'cds': cds,
                'fps': fps,
                'rating': 0,
                'id': __name__,
            })
        except:
            result.append({
                'url': sub_url,
                'FSrc': '[COLOR CC00FF00][B][I](bayflix) [/I][/B][/COLOR]',
                'info': info.encode('utf-8', 'replace'),
                'year': (item.get('release_date') or '')[:4],
                'cds': cds,
                'fps': fps,
                'rating': 0,
                'id': __name__,
            })

    if run_from_xbmc == False:
        for k in list_key:
            log_my([d[k] for d in result])

    return result


def get_sub(id, sub_url, filename):
    sub = {}

    try:
        r = requests.get(sub_url, headers=headers, timeout=30)
        r.raise_for_status()
    except Exception as e:
        log_my('bayflix.get_sub error:', str(e))
        return sub

    sub['data'] = r.content

    # Try to get filename from Content-Disposition
    cd = r.headers.get('Content-Disposition', '')
    m = re.search(r'filename="?([^";\s]+)"?', cd)
    if m:
        sub['fname'] = m.group(1)
    else:
        # Derive from URL path
        fname = sub_url.rstrip('/').split('/')[-1]
        if not fname.endswith('.zip'):
            fname += '.zip'
        sub['fname'] = fname

    return sub
