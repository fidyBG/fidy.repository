# -*- coding: utf-8 -*-
import os
import base64
import json
import urllib.request
import urllib.error

import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon()


def get_settings():
    return {
        'token':  ADDON.getSetting('github_token').strip(),
        'repo':   ADDON.getSetting('github_repo').strip(),
        'branch': ADDON.getSetting('github_branch').strip() or 'main',
        'path':   ADDON.getSetting('sync_path').strip(),
    }


def _github_request(method, url, token, data=None):
    headers = {
        'Authorization': 'token {}'.format(token),
        'Accept': 'application/vnd.github+json',
        'User-Agent': 'GitHub-Sync-Kodi/1.0',
        'Content-Type': 'application/json',
    }
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return resp.status, json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, {}


def upload_file(filepath, s):
    filename = os.path.basename(filepath)
    api_url = 'https://api.github.com/repos/{}/contents/{}'.format(s['repo'], filename)

    with open(filepath, 'rb') as f:
        content_b64 = base64.b64encode(f.read()).decode()

    status, resp = _github_request('GET', api_url + '?ref=' + s['branch'], s['token'])
    if status == 401:
        raise Exception('Невалиден токен!')
    sha = resp.get('sha') if status == 200 else None

    payload = {
        'message': 'sync: update {}'.format(filename),
        'content': content_b64,
        'branch':  s['branch'],
    }
    if sha:
        payload['sha'] = sha

    status, _ = _github_request('PUT', api_url, s['token'], payload)
    if status in (200, 201):
        return True
    elif status == 401:
        raise Exception('Невалиден токен!')
    elif status == 404:
        raise Exception('Репото не е намерено!')
    elif status == 422:
        raise Exception('Провери branch!')
    else:
        raise Exception('GitHub грешка {}'.format(status))


def sync_files(on_progress=None):
    def _progress(pct, msg):
        xbmc.log('[GitHub Sync] {}'.format(msg), xbmc.LOGINFO)
        if on_progress:
            on_progress(pct, msg)

    s = get_settings()

    if not s['token']:
        return 'Токенът не е зададен!'
    if not s['repo']:
        return 'Репото не е зададено!'
    if not s['path']:
        return 'Папката не е зададена!'
    os.makedirs(s['path'], exist_ok=True)

    files = [f for f in os.listdir(s['path'])
             if os.path.isfile(os.path.join(s['path'], f))]

    if not files:
        return 'Папката е празна!'

    errors = []
    for i, filename in enumerate(files):
        pct = int(10 + 85 * (i / len(files)))
        _progress(pct, 'Качване: {}...'.format(filename))
        try:
            upload_file(os.path.join(s['path'], filename), s)
        except Exception as exc:
            xbmc.log('[GitHub Sync] Грешка при {}: {}'.format(filename, exc), xbmc.LOGERROR)
            errors.append('{}: {}'.format(filename, exc))

    if errors:
        _progress(100, 'Завършено с грешки!')
        return '\n'.join(errors)

    _progress(100, 'Всички {} файла са качени успешно!'.format(len(files)))
    return None
