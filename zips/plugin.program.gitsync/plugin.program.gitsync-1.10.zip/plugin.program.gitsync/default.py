# -*- coding: utf-8 -*-
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
import core

import xbmc
import xbmcgui

ADDON = core.ADDON


def manual_sync():
    dialog = xbmcgui.DialogProgressBG()
    dialog.create('GitHub Sync', 'Синхронизацията започна...')
    try:
        error = core.sync_files(
            on_progress=lambda pct, msg: dialog.update(pct, 'GitHub Sync', msg)
        )
        dialog.close()
        if error:
            xbmcgui.Dialog().ok('GitHub Sync Грешка!', error)
        else:
            s = core.get_settings()
            files = [f for f in os.listdir(s['path']) if os.path.isfile(os.path.join(s['path'], f))]
            xbmcgui.Dialog().notification(
                'GitHub Sync',
                'Успешна синхронизация!'.format(len(files)),
                xbmcgui.NOTIFICATION_INFO, 4000
            )
    except Exception as exc:
        dialog.close()
        xbmc.log('[GitHub Sync] Грешка: {}'.format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().ok('GitHub Sync Грешка!', str(exc))


manual_sync()
