# -*- coding: utf-8 -*-
import os
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))
import core

import xbmc
import xbmcgui

ADDON = core.ADDON


class GitHubSyncService(xbmc.Monitor):

    def _sync_with_progress(self):
        dialog = xbmcgui.DialogProgressBG()
        dialog.create('GitHub Sync', 'Синхронизацията започна...')
        try:
            error = core.sync_files(
                on_progress=lambda pct, msg: dialog.update(pct, 'GitHub Sync', msg)
            )
            dialog.close()
            if error:
                xbmc.log('[GitHub Sync] Грешка: {}'.format(error), xbmc.LOGERROR)
            else:
                xbmcgui.Dialog().notification(
                    'GitHub Sync', 'Синхронизацията е успешна!',
                    xbmcgui.NOTIFICATION_INFO, 3000
                )
        except Exception as exc:
            dialog.close()
            xbmc.log('[GitHub Sync] Неочаквана грешка: {}'.format(exc), xbmc.LOGERROR)

    def run(self):
        xbmc.log('[GitHub Sync] Услугата стартира.', xbmc.LOGINFO)

        if ADDON.getSetting('sync_on_start') == 'true':
            self._sync_with_progress()

        last_sync = time.time()

        while not self.waitForAbort(60):
            sync_hours = int(float(ADDON.getSetting('sync_hours') or 6))
            if time.time() - last_sync >= sync_hours * 3600:
                self._sync_with_progress()
                last_sync = time.time()

        xbmc.log('[GitHub Sync] Услугата спря.', xbmc.LOGINFO)


if __name__ == '__main__':
    GitHubSyncService().run()
