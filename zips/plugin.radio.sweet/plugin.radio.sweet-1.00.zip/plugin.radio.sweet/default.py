import sys
import xbmcgui
import xbmcplugin
import xbmcaddon
import os

def run():
    handle = int(sys.argv[1])
    addon = xbmcaddon.Addon()
    addon_path = addon.getAddonInfo('path')
    
    logo = os.path.join(addon_path, 'icon.png')
    fanart = os.path.join(addon_path, 'fanart.jpg')
    
    url = "https://stream.sweetradio.online:8001/HD"
    
    list_item = xbmcgui.ListItem(label="Sweet Radio Bulgaria Stream HD")
    
    list_item.setArt({
        'thumb': logo,
        'icon': logo,
        'fanart': fanart,
        'poster': fanart
    })
    
    list_item.setInfo('music', {
        'title': "Sweet Radio Bulgaria",
        'artist': "Deep House, Indie & Dance",
        'album': "Live Stream"
    })
    
    list_item.setProperty('IsPlayable', 'true')

    xbmcplugin.addDirectoryItem(handle, url, list_item, False)
    xbmcplugin.endOfDirectory(handle)

if __name__ == '__main__':
    run()
    